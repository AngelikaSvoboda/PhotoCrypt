#!/usr/bin/python
# -*- coding: utf-8 -*-

import datetime

import socket 
from threading import Thread 
from SocketServer import ThreadingMixIn

import Image, ImageDraw
import random

# Multithreaded Python server : TCP Server Socket Thread Pool
class ClientThread(Thread):
	
	

	#Eingabe eines Pixels, 255 für weiss und 0 für schwarz
	def encryptPixel(self, pixelValue):
		#Zufalls Vierer Pixel für weiss
		#whitePixel1 = [[0,1,1,0],[0,1,1,0]]
		#whitePixel2 = [[1,0,0,1],[1,0,0,1]]
		#whitePixel3 = [[0,1,0,1],[0,1,0,1]]
		#whitePixel4 = [[1,0,1,0],[1,0,1,0]]
		#Zufalls Vierer Pixel für schwarz
		#blackPixel1 = [[0,1,1,0],[1,0,0,1]]
		#blackPixel2 = [[1,0,0,1],[0,1,1,0]]
		#blackPixel3 = [[0,1,0,1],[1,0,1,0]]
		#blackPixel4 = [[1,0,1,0],[0,1,0,1]]
		
		#Zufalls Vierer Pixel für weiss
		whitePixel1 = [[255,0,0,255],[255,0,0,255]]
		whitePixel2 = [[0,255,255,0],[0,255,255,0]]
		whitePixel3 = [[255,0,255,0],[255,0,255,0]]
		whitePixel4 = [[0,255,0,255],[0,255,0,255]]
		#Zufalls Vierer Pixel für schwarz
		blackPixel1 = [[255,0,0,255],[0,255,255,0]]
		blackPixel2 = [[0,255,255,0],[255,0,0,255]]
		blackPixel3 = [[255,0,255,0],[0,255,0,255]]
		blackPixel4 = [[0,255,0,255],[255,0,255,0]]
		
		rnd = random.randint(1,4)
		#weisser Pixel
		if(pixelValue==255):
			if (rnd==1): return whitePixel1
			elif (rnd==2): return whitePixel2
			elif(rnd==3): return whitePixel3
			else: return whitePixel4
			
		else:
			if(rnd==1): return blackPixel1
			elif (rnd==2): return blackPixel2
			elif(rnd==3): return blackPixel3
			else: return blackPixel4
			
		return "falsches Format"

	def __init__(self,ip,port): 
		Thread.__init__(self) 
		self.ip = ip 
		self.port = port 
		print ("[+] New server socket thread started for " + ip + ":" + str(port) )
		
	def run(self):
		time = datetime.datetime.now()
		name = 'picture' + time.strftime("%d") + time.strftime("%m") + time.strftime("%Y") + time.strftime("%H") + time.strftime("%M") + time.strftime("%S") + time.strftime("%f") + '.png'
		f = open(name, 'w+')
		while True : 
			data = conn.recv(1024) 
			print ("Server received data:", data)
			#MESSAGE = raw_input("Multithreaded Python server : Enter Response from Server/Enter exit:")
			#if MESSAGE == 'exit':
			while(data):
				f.write(data)
				data = conn.recv(1024)
			f.close()
			conn.close()
			break
		
		# Algorithmus
		image = Image.open(name)
		width, height = image.size
		print (height)
		print (width)
		print image.size
		
		# Ausgabedateien vorerst zwei Bilder
		#encrypted1 = Image.open("enc1_" + name, "rb")
		#encrypted2 = Image.open("enc2_" + name, "rb")
		encrypted1 = Image.new("1", (width*2, height*2))
		encrypted2 = Image.new("1", (width*2, height*2))
		
		row = 0
		column = 0
		while column < width:
			while row < height:
				print column
				print row
				pix = image.getpixel((column, row))
				print pix
				result = self.encryptPixel(pix)
				# Zeichne in jedes Bild die vier Pixel
				draw1 = ImageDraw.Draw(encrypted1)
				draw2 = ImageDraw.Draw(encrypted2)
				draw1.point((column*2,row*2), result[0][0])
				draw1.point((column*2+1,row*2), result[0][1])
				draw1.point((column*2,row*2+1), result[0][2])
				draw1.point((column*2+1,row*2+1), result[0][3])
				#del draw
				#encrypted1.save(sys.stdout, "PNG")
				#fill = "rgb(" + result[1][0] + ","+ result[1][0] + ","+ result[1][0] + ")"
				#draw = ImageDraw.Draw(encrypted2)
				draw2.point((column*2,row*2), result[1][0])
				draw2.point((column*2+1,row*2), result[1][1])
				draw2.point((column*2,row*2+1), result[1][2])
				draw2.point((column*2+1,row*2+1), result[1][3])
				#del draw
				#encrypted2.save(sys.stdout, "PNG")
				
				row = row+1
			column= column+1
			row = 0
		del draw1
		del draw2
		encrypted1.save("enc1_" + name, "PNG")
		encrypted2.save("enc2_" + name, "PNG")
	
	

# Multithreaded Python server : TCP Server Socket Program Stub
TCP_IP = '0.0.0.0' 
TCP_PORT = 9999 

tcpServer = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
tcpServer.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1) 
tcpServer.bind((TCP_IP, TCP_PORT)) 
threads = []

while True: 
	tcpServer.listen(4) 
	print ("Multithreaded Python server : Waiting for connections from TCP clients..." )
	(conn, (ip,port)) = tcpServer.accept() 
	newthread = ClientThread(ip,port) 
	newthread.start() 
	threads.append(newthread)
	
for t in threads: 
	t.join() 
