# Python TCP Client A
import socket
 
host = socket.gethostname() 
port = 9999
BUFFER_SIZE = 2000 
 
tcpClient = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
tcpClient.connect((host, port))
 
f = open('smiley.png', 'rb')
data = f.read(1024)
while(data):
	tcpClient.send(data)
	data = f.read(1024)
	
f.close
 
tcpClient.shutdown
